/**
 * xp-grind.js — Standalone hack XP grinder
 *
 * Fills ALL available RAM on home + purchased servers with weaken() threads
 * against a low-security target (default: joesguns). Weaken gives full XP
 * regardless of outcome (unlike hack which gives 25% on failure).
 *
 * XP per cycle = threads × baseDifficulty × 0.004 × HackExpGain mult
 *
 * Why weaken over hack?
 *   - hack() gives 25% XP on failure, weaken() always gives 100%
 *   - With high hack level, hack chance is 100% but weaken is still faster
 *     because it doesn't depend on server money state
 *   - No desync risk — weaken can't "break" the server state
 *
 * Usage: run xp-grind.js [target] [--reserve 128]
 * @param {NS} ns
 */
export async function main(ns) {
    const flags = ns.flags([
        ['reserve', 128],    // GB to keep free on home (room for sleeve.js, stockmaster, etc.)
        ['include-world', true], // Use rooted world servers too (default: on)
    ]);
    const target = ns.args[0] ?? 'joesguns';
    const reserveRam = flags['reserve'];
    const includeWorld = flags['include-world'];

    ns.disableLog('ALL');

    if (!ns.serverExists(target)) {
        ns.tprint(`ERROR: Server "${target}" doesn't exist.`);
        return;
    }
    if (!ns.hasRootAccess(target)) {
        ns.tprint(`ERROR: No root access on "${target}".`);
        return;
    }

    // Worker script — minimal weaken loop (1.75 GB)
    const WORKER = '/Temp/xp-weaken-loop.js';
    ns.write(WORKER, [
        'export async function main(ns) {',
        '  while (true) await ns.weaken(ns.args[0]);',
        '}',
    ].join('\n'), 'w');

    const workerRam = ns.getScriptRam(WORKER, 'home');

    // Collect all hosts we can use
    function getHosts() {
        const hosts = ['home'];
        try { hosts.push(...ns.cloud.getServerNames()); } catch { /* no cloud API */ }
        if (includeWorld) {
            const visited = new Set(), queue = ['home'];
            while (queue.length > 0) {
                const h = queue.shift();
                if (visited.has(h)) continue;
                visited.add(h);
                if (h !== 'home' && !h.startsWith('hacknet') && ns.hasRootAccess(h) && ns.getServerMaxRam(h) >= workerRam)
                    hosts.push(h);
                for (const n of ns.scan(h)) if (!visited.has(n)) queue.push(n);
            }
        }
        return [...new Set(hosts)]; // deduplicate
    }

    ns.tprint(`XP Grind: target=${target} (baseSec=${ns.getServerMinSecurityLevel(target)}) reserve=${reserveRam}GB`);

    // Clean up workers when this script is killed (by autopilot or user)
    ns.atExit(() => {
        for (const host of getHosts()) {
            for (const proc of ns.ps(host)) {
                if (proc.filename === WORKER) ns.kill(proc.pid);
            }
        }
    });

    let totalThreads = 0;
    const hosts = getHosts();

    for (const host of hosts) {
        // Copy worker to remote
        if (host !== 'home') ns.scp(WORKER, host, 'home');

        // Kill any existing XP workers on this host
        for (const proc of ns.ps(host)) {
            if (proc.filename === WORKER) ns.kill(proc.pid);
        }

        const maxRam = ns.getServerMaxRam(host);
        const usedRam = ns.getServerUsedRam(host);
        const reserve = host === 'home' ? reserveRam : 0;
        const freeRam = Math.max(0, maxRam - usedRam - reserve);
        const threads = Math.floor(freeRam / workerRam);

        if (threads <= 0) continue;

        const pid = ns.exec(WORKER, host, threads, target);
        if (pid > 0) {
            totalThreads += threads;
            ns.tprint(`  ${host}: ${threads} threads (${ns.format.ram(threads * workerRam)})`);
        }
    }

    const baseSec = ns.getServerMinSecurityLevel(target);
    const xpPerCycle = totalThreads * baseSec * 0.004;
    const weakenTime = ns.getWeakenTime(target);

    ns.tprint(`\nTotal: ${totalThreads.toLocaleString()} threads across ${hosts.length} hosts`);
    ns.tprint(`Est XP/cycle: ${xpPerCycle.toLocaleString()} (×HackExpGain mult)`);
    ns.tprint(`Weaken time: ${(weakenTime/1000).toFixed(1)}s`);
    ns.tprint(`Est XP/sec: ~${(xpPerCycle / (weakenTime/1000)).toFixed(0)}`);
    ns.tprint(`\nWorkers are looping. Kill this script + workers when done.`);
    ns.tprint(`To stop: killall ${WORKER}`);

    // Stay alive to show status
    while (true) {
        const sec = ns.getServerSecurityLevel(target);
        const minSec = ns.getServerMinSecurityLevel(target);
        ns.print(`[${new Date().toLocaleTimeString()}] ${target}: sec=${sec.toFixed(2)}/${minSec} | ${totalThreads.toLocaleString()} threads | ~${(xpPerCycle / (weakenTime/1000)).toFixed(0)} XP/s`);
        await ns.sleep(10000);
    }
}