export async function main(ns) {
    for (const s of ns.cloud.getServerNames())
        ns.scp('hwgw-grow.js', s, 'home');
    ns.tprint('Done — hwgw-grow.js copied to all purchased servers.');
}